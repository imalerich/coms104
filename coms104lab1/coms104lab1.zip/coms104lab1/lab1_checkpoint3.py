# This is my first Python script
print 2+3
print "Hello, World!"
